# environment
conda install --yes --file requirements.txt
or
pip install -r requirements.txt

# command line
python main.py
